﻿# IMPROVED GLOWING RINGS

**Trait:** Agility; **Range:** Very Close; **Damage:** d10+5 mag; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 2*
