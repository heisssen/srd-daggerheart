﻿# UROK BROADSWORD

**Trait:** Finesse; **Range:** Melee; **Damage:** d8+3 phy; **Burden:** One-Handed

**Feature:** ***Deadly:*** When you deal Severe damage, the target must mark an additional HP.

*Primary Weapon - Tier 2*
