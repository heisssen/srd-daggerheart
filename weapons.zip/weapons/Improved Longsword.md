﻿# IMPROVED LONGSWORD

**Trait:** Agility; **Range:** Melee; **Damage:** d8+6 phy; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 2*
