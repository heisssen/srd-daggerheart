﻿# STEELFORGED HALBERD

**Trait:** Strength; **Range:** Very Close; **Damage:** d8+4 phy; **Burden:** Two-Handed

**Feature:** ***Scary:*** On a successful attack, the target must mark a Stress.

*Primary Weapon - Tier 2*
