﻿# DUAL-ENDED SWORD

**Trait:** Agility; **Range:** Melee; **Damage:** d10+9 phy; **Burden:** Two-Handed

**Feature:** ***Quick:*** When you make an attack, you can mark a Stress to target another creature within range.

*Primary Weapon - Tier 4*
