﻿# SWORD OF LIGHT AND FLAME

**Trait:** Strength; **Range:** Melee; **Damage:** d10+11 mag; **Burden:** Two-Handed

**Feature:** ***Hot:*** This weapon cuts through solid material.

*Primary Weapon - Tier 4*
