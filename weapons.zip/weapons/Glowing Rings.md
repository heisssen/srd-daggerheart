﻿# GLOWING RINGS

**Trait:** Agility; **Range:** Very Close; **Damage:** d10+1 mag; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 1*
