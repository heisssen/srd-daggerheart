﻿# BUCKLER

**Trait:** Agility; **Range:** Melee; **Damage:** d4+4 phy; **Burden:** One-Handed

**Feature:** ***Deflecting:*** When you are attacked, you can mark an Armor Slot to gain a bonus to your Evasion equal to your Armor Score against the attack.

*Secondary Weapon - Tier 3*
