﻿# FINEHAIR BOW

**Trait:** Agility; **Range:** Very Far; **Damage:** d6+5 phy; **Burden:** Two-Handed

**Feature:** ***Reliable:*** +1 to attack rolls

*Primary Weapon - Tier 2*
