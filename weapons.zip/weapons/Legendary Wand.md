﻿# LEGENDARY WAND

**Trait:** Knowledge; **Range:** Far; **Damage:** d6+10 mag; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 4*
