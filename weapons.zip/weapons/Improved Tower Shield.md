﻿# IMPROVED TOWER SHIELD

**Trait:** Strength; **Range:** Melee; **Damage:** d6+2 phy; **Burden:** One-Handed

**Feature:** ***Barrier:*** +3 to Armor Score; -1 to Evasion

*Secondary Weapon - Tier 2*
