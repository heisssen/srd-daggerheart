﻿# RETURNING BLADE

**Trait:** Finesse; **Range:** Close; **Damage:** d8 mag; **Burden:** One-Handed

**Feature:** ***Returning:*** When this weapon is thrown within its range, it appears in your hand immediately after the attack.

*Primary Weapon - Tier 1*
