﻿# CASTING SWORD

**Trait:** Strength; **Range:** Melee; **Damage:** d10+4 mag; **Burden:** Two-Handed

**Feature:** ***Versatile:*** This weapon can also be used with these statistics—Knowledge, Far, d6+3.

*Primary Weapon - Tier 2*
