﻿# IMPROVED SPEAR

**Trait:** Finesse; **Range:** Very Close; **Damage:** d10+5 phy; **Burden:** Two-Handed

**Feature:** ***Cumbersome:*** -1 to Finesse

*Primary Weapon - Tier 2*
