﻿# MERIDIAN CUTLASS

**Trait:** Presence; **Range:** Melee; **Damage:** d10+5 phy; **Burden:** One-Handed

**Feature:** ***Dueling:*** When there are no other creatures within Close range of the target, gain advantage on your attack roll against them.

*Primary Weapon - Tier 3*
