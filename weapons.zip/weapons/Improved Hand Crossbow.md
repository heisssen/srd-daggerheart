﻿# IMPROVED HAND CROSSBOW

**Trait:** Finesse; **Range:** Far; **Damage:** d6+3 phy; **Burden:** One-Handed

**Feature:** —

*Secondary Weapon - Tier 2*
