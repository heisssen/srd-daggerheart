﻿# KNUCKLE BLADES

**Trait:** Strength; **Range:** Melee; **Damage:** d10+6 phy; **Burden:** One-Handed

**Feature:** ***Brutal:*** When you roll the maximum value on a damage die, roll an additional damage die.

*Primary Weapon - Tier 2*
