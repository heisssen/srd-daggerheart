﻿# ADVANCED LONGBOW

**Trait:** Agility; **Range:** Very Far; **Damage:** d8+9 phy; **Burden:** Two-Handed

**Feature:** ***Cumbersome:*** -1 to Finesse

*Primary Weapon - Tier 3*
