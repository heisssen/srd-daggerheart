﻿# TALON BLADES

**Trait:** Finesse; **Range:** Close; **Damage:** d10+7 phy; **Burden:** Two-Handed

**Feature:** ***Brutal:*** When you roll the maximum value on a damage die, roll an additional damage die.

*Primary Weapon - Tier 3*
