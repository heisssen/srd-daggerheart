﻿# HALLOWED AXE

**Trait:** Strength; **Range:** Melee; **Damage:** d8+1 mag; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 1*
