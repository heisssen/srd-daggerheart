﻿# ARCANE GAUNTLETS

**Trait:** Strength; **Range:** Melee; **Damage:** d10+3 mag; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 1*
