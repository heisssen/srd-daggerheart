﻿# FLOATING BLADESHARDS

**Trait:** Instinct; **Range:** Close; **Damage:** d8+9 mag; **Burden:** One-Handed

**Feature:** ***Powerful:*** On a successful attack, roll an additional damage die and discard the lowest result.

*Primary Weapon - Tier 4*
