﻿# BRAVESHIELD

**Trait:** Agility; **Range:** Melee; **Damage:** d4+6 phy; **Burden:** One-Handed

**Feature:** ***Sheltering:*** When you mark an Armor Slot, it reduces damage for you and all allies within Melee range of you who took the same damage.

*Secondary Weapon - Tier 4*
