﻿# WAND OF ESSEK

**Trait:** Knowledge; **Range:** Far; **Damage:** d8+13 mag; **Burden:** One-Handed

**Feature:** ***Timebending:*** You can choose the target of your attack after making your attack roll.

*Primary Weapon - Tier 4*
