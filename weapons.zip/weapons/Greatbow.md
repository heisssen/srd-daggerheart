﻿# GREATBOW

**Trait:** Strength; **Range:** Far; **Damage:** d6+6 phy; **Burden:** Two-Handed

**Feature:** ***Powerful:*** On a successful attack, roll an additional damage die and discard the lowest result.

*Primary Weapon - Tier 2*
