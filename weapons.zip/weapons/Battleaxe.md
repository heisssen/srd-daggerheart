﻿# BATTLEAXE

**Trait:** Strength; **Range:** Melee; **Damage:** d10+3 phy; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 1*
