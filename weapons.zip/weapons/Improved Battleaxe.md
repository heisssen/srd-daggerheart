﻿# IMPROVED BATTLEAXE

**Trait:** Strength; **Range:** Melee; **Damage:** d10+6 phy; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 2*
