﻿# ADVANCED TOWER SHIELD

**Trait:** Strength; **Range:** Melee; **Damage:** d6+4 phy; **Burden:** One-Handed

**Feature:** ***Barrier:*** +4 to Armor Score; –1 to Evasion

*Secondary Weapon - Tier 3*
