﻿# EGO BLADE

**Trait:** Agility; **Range:** Melee; **Damage:** d12+4 mag; **Burden:** One-Handed

**Feature:** ***Pompous:*** You must have a Presence of 0 or lower to use this weapon.

*Primary Weapon - Tier 2*
