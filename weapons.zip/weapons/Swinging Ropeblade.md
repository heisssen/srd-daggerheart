﻿# SWINGING ROPEBLADE

**Trait:** Presence; **Range:** Close; **Damage:** d8+9 phy; **Burden:** One-Handed

**Feature:** ***Grappling:*** On a successful attack, you can spend a Hope to Restrain the target or pull them into Melee range with you.

*Primary Weapon - Tier 4*
