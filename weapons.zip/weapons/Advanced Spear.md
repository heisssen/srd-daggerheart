﻿# ADVANCED SPEAR

**Trait:** Finesse; **Range:** Very Close; **Damage:** d10+8 phy; **Burden:** Two-Handed

**Feature:** ***Cumbersome:*** -1 to Finesse

*Primary Weapon - Tier 3*
