﻿# LEGENDARY CROSSBOW

**Trait:** Finesse; **Range:** Far; **Damage:** d6+10 phy; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 4*
