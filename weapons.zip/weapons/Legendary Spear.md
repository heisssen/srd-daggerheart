﻿# LEGENDARY SPEAR

**Trait:** Finesse; **Range:** Very Close; **Damage:** d10+11 phy; **Burden:** Two-Handed

**Feature:** ***Cumbersome:*** -1 to Finesse

*Primary Weapon - Tier 4*
