﻿# LEGENDARY TOWER SHIELD

**Trait:** Strength; **Range:** Melee; **Damage:** d6+6 phy; **Burden:** One-Handed

**Feature:** ***Barrier:*** +5 to Armor Score; –1 to Evasion.

*Secondary Weapon - Tier 4*
