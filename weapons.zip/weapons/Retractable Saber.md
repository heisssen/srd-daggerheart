﻿# RETRACTABLE SABER

**Trait:** Presence; **Range:** Melee; **Damage:** d10+7 phy; **Burden:** One-Handed

**Feature:** ***Retractable:*** The blade can be hidden in the hilt to avoid detection.

*Primary Weapon - Tier 3*
