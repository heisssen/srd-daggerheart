﻿# IMPROVED GREATSWORD

**Trait:** Strength; **Range:** Melee; **Damage:** d10+6 phy; **Burden:** Two-Handed

**Feature:** ***Massive:*** -1 to Evasion; on a successful attack, roll an additional damage die and discard the lowest result.

*Primary Weapon - Tier 2*
