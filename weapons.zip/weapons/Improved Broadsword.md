﻿# IMPROVED BROADSWORD

**Trait:** Agility; **Range:** Melee; **Damage:** d8+3 phy; **Burden:** One-Handed

**Feature:** ***Reliable:*** +1 to attack rolls

*Primary Weapon - Tier 2*
