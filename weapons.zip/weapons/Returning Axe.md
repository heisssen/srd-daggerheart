﻿# RETURNING AXE

**Trait:** Agility; **Range:** Close; **Damage:** d6+4 phy; **Burden:** One-Handed

**Feature:** ***Returning:*** When this weapon is thrown within its range, it appears in your hand immediately after the attack.

*Secondary Weapon - Tier 2*
