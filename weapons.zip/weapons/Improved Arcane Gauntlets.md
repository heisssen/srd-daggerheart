﻿# IMPROVED ARCANE GAUNTLETS

**Trait:** Strength; **Range:** Melee; **Damage:** d10+6 mag; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 2*
