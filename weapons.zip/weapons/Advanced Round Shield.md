﻿# ADVANCED ROUND SHIELD

**Trait:** Strength; **Range:** Melee; **Damage:** d4+4 phy; **Burden:** One-Handed

**Feature:** ***Protective:*** +3 to Armor Score

*Secondary Weapon - Tier 3*
