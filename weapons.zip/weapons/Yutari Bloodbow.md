﻿# YUTARI BLOODBOW

**Trait:** Finesse; **Range:** Far; **Damage:** d6+4 mag; **Burden:** Two-Handed

**Feature:** ***Brutal:*** When you roll the maximum value on a damage die, roll an additional damage die.

*Primary Weapon - Tier 2*
