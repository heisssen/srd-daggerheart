﻿# LABRYS AXE

**Trait:** Strength; **Range:** Melee; **Damage:** d10+7 phy; **Burden:** Two-Handed

**Feature:** ***Protective:*** +1 to Armor Score

*Primary Weapon - Tier 3*
