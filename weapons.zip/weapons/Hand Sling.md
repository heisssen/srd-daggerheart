﻿# HAND SLING

**Trait:** Finesse; **Range:** Very Close; **Damage:** d6+4 phy; **Burden:** One-Handed

**Feature:** ***Versatile:*** This weapon can also be used with these statistics—Finesse, Close, d8+4.

*Secondary Weapon - Tier 3*
