﻿# FUSION GLOVES

**Trait:** Knowledge; **Range:** Very Far; **Damage:** d6+9 mag; **Burden:** Two-Handed

**Feature:** ***Bonded:*** Gain a bonus to your damage rolls equal to your level.

*Primary Weapon - Tier 4*
