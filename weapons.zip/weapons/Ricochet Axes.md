﻿# RICOCHET AXES

**Trait:** Agility; **Range:** Far; **Damage:** d6+11 phy; **Burden:** Two-Handed

**Feature:** ***Bouncing:*** Mark 1 or more Stress to hit that many targets in range of the attack.

*Primary Weapon - Tier 4*
