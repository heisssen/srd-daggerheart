﻿# SHORTBOW

**Trait:** Agility; **Range:** Far; **Damage:** d6+3 phy; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 1*
