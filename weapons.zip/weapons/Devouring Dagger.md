﻿# DEVOURING DAGGER

**Trait:** Finesse; **Range:** Melee; **Damage:** d8+4 mag; **Burden:** One-Handed

**Feature:** ***Scary:*** On a successful attack, the target must mark a Stress.

*Primary Weapon - Tier 2*
