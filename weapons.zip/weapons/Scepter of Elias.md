﻿# SCEPTER OF ELIAS

**Trait:** Presence; **Range:** Far; **Damage:** d6+3 mag; **Burden:** One-Handed

**Feature:** ***Invigorating:*** On a successful attack, roll a d4. On a result of 4, clear a Stress.

*Primary Weapon - Tier 2*
