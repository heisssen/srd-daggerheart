﻿# LEGENDARY ROUND SHIELD

**Trait:** Strength; **Range:** Melee; **Damage:** d4+6 phy; **Burden:** One-Handed

**Feature:** ***Protective:*** +4 to Armor Score

*Secondary Weapon - Tier 4*
