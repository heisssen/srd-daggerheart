﻿# LEGENDARY CUTLASS

**Trait:** Presence; **Range:** Melee; **Damage:** d8+10 phy; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 4*
