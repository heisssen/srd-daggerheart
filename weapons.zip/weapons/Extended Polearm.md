﻿# EXTENDED POLEARM

**Trait:** Finesse; **Range:** Very Close; **Damage:** d8+10 phy; **Burden:** Two-Handed

**Feature:** ***Long:*** This weapon’s attack targets all adversaries in a line within range.

*Primary Weapon - Tier 4*
