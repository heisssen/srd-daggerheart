﻿# IMPROVED WAND

**Trait:** Knowledge; **Range:** Far; **Damage:** d6+4 mag; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 2*
