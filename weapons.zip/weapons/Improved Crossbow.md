﻿# IMPROVED CROSSBOW

**Trait:** Finesse; **Range:** Far; **Damage:** d6+4 phy; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 2*
