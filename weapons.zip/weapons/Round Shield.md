﻿# ROUND SHIELD

**Trait:** Strength; **Range:** Melee; **Damage:** d4 phy; **Burden:** One-Handed

**Feature:** ***Protective:*** +1 to Armor Score

*Secondary Weapon - Tier 1*
