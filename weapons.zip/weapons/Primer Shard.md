﻿# PRIMER SHARD

**Trait:** Instinct; **Range:** Very Close; **Damage:** d4 phy; **Burden:** One-Handed

**Feature:** ***Locked On:*** On a successful attack, your next attack against the same target with your primary weapon automatically succeeds.

*Secondary Weapon - Tier 4*
