﻿# SIPHONING GAUNTLETS

**Trait:** Presence; **Range:** Melee; **Damage:** d10+9 mag; **Burden:** Two-Handed

**Feature:** ***Lifestealing:*** On a successful attack, roll a d6. On a result of 6, clear a Hit Point or clear a Stress.

*Primary Weapon - Tier 4*
