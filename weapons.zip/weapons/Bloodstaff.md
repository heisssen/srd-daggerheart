﻿# BLOODSTAFF

**Trait:** Instinct; **Range:** Far; **Damage:** d20+7 mag; **Burden:** Two-Handed

**Feature:** ***Painful:*** Each time you make a successful attack, you must mark a Stress.

*Primary Weapon - Tier 4*
