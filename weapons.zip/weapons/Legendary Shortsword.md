﻿# LEGENDARY SHORTSWORD

**Trait:** Agility; **Range:** Melee; **Damage:** d8+6 phy; **Burden:** One-Handed

**Feature:** ***Paired:*** +5 to primary weapon damage to targets within Melee range

*Secondary Weapon - Tier 4*
