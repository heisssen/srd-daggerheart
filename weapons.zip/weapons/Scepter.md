﻿# SCEPTER

**Trait:** Presence; **Range:** Far; **Damage:** d6 mag; **Burden:** Two-Handed

**Feature:** ***Versatile:*** This weapon can also be used with these statistics—Presence, Melee, d8.

*Primary Weapon - Tier 1*
