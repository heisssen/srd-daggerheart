﻿# LONGSWORD

**Trait:** Agility; **Range:** Melee; **Damage:** d8+3 phy; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 1*
