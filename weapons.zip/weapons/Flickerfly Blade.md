﻿# FLICKERFLY BLADE

**Trait:** Agility; **Range:** Melee; **Damage:** d8+5 phy; **Burden:** One-Handed

**Feature:** ***Sharpening:*** Gain a bonus to your damage rolls equal to your Agility.

*Primary Weapon - Tier 3*
