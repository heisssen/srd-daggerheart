﻿# THISTLEBOW

**Trait:** Instinct; **Range:** Far; **Damage:** d6+13 mag; **Burden:** Two-Handed

**Feature:** ***Reliable:*** +1 to attack rolls

*Primary Weapon - Tier 4*
