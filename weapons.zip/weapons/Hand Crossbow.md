﻿# HAND CROSSBOW

**Trait:** Finesse; **Range:** Far; **Damage:** d6+1 phy; **Burden:** One-Handed

**Feature:** —

*Secondary Weapon - Tier 1*
