﻿# BLUNDERBUSS

**Trait:** Finesse; **Range:** Close; **Damage:** d8+6 phy; **Burden:** Two-Handed

**Feature:** ***Reloading:*** After you make an attack, roll a d6. On a result of 1, you must mark a Stress to reload this weapon before you can fire it again.

*Primary Weapon - Tier 2*
