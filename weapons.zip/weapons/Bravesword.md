﻿# BRAVESWORD

**Trait:** Strength; **Range:** Melee; **Damage:** d12+7 phy; **Burden:** Two-Handed

**Feature:** ***Brave:*** -1 to Evasion; +3 to Severe damage threshold

*Primary Weapon - Tier 3*
