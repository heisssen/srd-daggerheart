﻿# HAND CANNON

**Trait:** Finesse; **Range:** Very Far; **Damage:** d6+12 phy; **Burden:** One-Handed

**Feature:** ***Reloading:*** After you make an attack, roll a d6. On a 1, you must mark a Stress to reload this weapon before you can fire it again.

*Primary Weapon - Tier 4*
