﻿# WAND OF ENTHRALLMENT

**Trait:** Presence; **Range:** Far; **Damage:** d6+4 mag; **Burden:** One-Handed

**Feature:** ***Persuasive:*** Before you make a Presence Roll, you can mark a Stress to gain a +2 bonus to the result.

*Primary Weapon - Tier 2*
