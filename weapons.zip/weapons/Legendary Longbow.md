﻿# LEGENDARY LONGBOW

**Trait:** Agility; **Range:** Very Far; **Damage:** d8+12 phy; **Burden:** Two-Handed

**Feature:** ***Cumbersome:*** -1 to Finesse

*Primary Weapon - Tier 4*
