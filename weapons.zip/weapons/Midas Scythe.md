﻿# MIDAS SCYTHE

**Trait:** Knowledge; **Range:** Melee; **Damage:** d10+9 mag; **Burden:** Two-Handed

**Feature:** ***Greedy:*** Spend a handful of gold to gain a +1 bonus to your Proficiency on a damage roll.

*Primary Weapon - Tier 4*
