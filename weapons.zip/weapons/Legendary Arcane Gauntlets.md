﻿# LEGENDARY ARCANE GAUNTLETS

**Trait:** Strength; **Range:** Melee; **Damage:** d10+12 mag; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 4*
