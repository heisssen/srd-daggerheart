﻿# LEGENDARY WHIP

**Trait:** Presence; **Range:** Very Close; **Damage:** d6+6 phy; **Burden:** One-Handed

**Feature:** ***Startling:*** Mark a Stress to crack the whip and force all adversaries within Melee range back to Close range.

*Secondary Weapon - Tier 4*
