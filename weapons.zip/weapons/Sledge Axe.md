﻿# SLEDGE AXE

**Trait:** Strength; **Range:** Melee; **Damage:** d12+13 phy; **Burden:** Two-Handed

**Feature:** ***Destructive:*** -1 to Agility; on a successful attack, all adversaries within Very Close range must mark a Stress.

*Primary Weapon - Tier 4*
