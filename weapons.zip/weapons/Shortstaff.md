﻿# SHORTSTAFF

**Trait:** Instinct; **Range:** Close; **Damage:** d8+1 mag; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 1*
