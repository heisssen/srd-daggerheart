﻿# ELDER BOW

**Trait:** Instinct; **Range:** Far; **Damage:** d6+4 mag; **Burden:** Two-Handed

**Feature:** ***Powerful:*** On a successful attack, roll an additional damage die and discard the lowest result.

*Primary Weapon - Tier 2*
