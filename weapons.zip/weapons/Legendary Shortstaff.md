﻿# LEGENDARY SHORTSTAFF

**Trait:** Instinct; **Range:** Close; **Damage:** d8+10 mag; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 4*
