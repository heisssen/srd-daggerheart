﻿# ADVANCED HAND CROSSBOW

**Trait:** Finesse; **Range:** Far; **Damage:** d6+5 phy; **Burden:** One-Handed

**Feature:** —

*Secondary Weapon - Tier 3*
