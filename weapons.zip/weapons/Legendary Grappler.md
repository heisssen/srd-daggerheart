﻿# LEGENDARY GRAPPLER

**Trait:** Finesse; **Range:** Close; **Damage:** d6+6 phy; **Burden:** One-Handed

**Feature:** ***Hooked:*** On a successful attack, you can pull the target into Melee range.

*Secondary Weapon - Tier 4*
