﻿# LEGENDARY GLOWING RINGS

**Trait:** Agility; **Range:** Very Close; **Damage:** d10+11 mag; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 4*
