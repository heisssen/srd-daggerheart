﻿# LEGENDARY QUARTERSTAFF

**Trait:** Instinct; **Range:** Melee; **Damage:** d10+12 phy; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 4*
