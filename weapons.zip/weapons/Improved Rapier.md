﻿# IMPROVED RAPIER

**Trait:** Presence; **Range:** Melee; **Damage:** d8+3 phy; **Burden:** One-Handed

**Feature:** ***Quick:*** When you make an attack, you can mark a Stress to target another creature within range.

*Primary Weapon - Tier 2*
