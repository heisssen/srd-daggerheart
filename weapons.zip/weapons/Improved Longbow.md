﻿# IMPROVED LONGBOW

**Trait:** Agility; **Range:** Very Far; **Damage:** d8+6 phy; **Burden:** Two-Handed

**Feature:** ***Cumbersome:*** -1 to Finesse

*Primary Weapon - Tier 2*
