﻿# SPIKED BOW

**Trait:** Agility; **Range:** Very Far; **Damage:** d6+7 phy; **Burden:** Two-Handed

**Feature:** ***Versatile:*** This weapon can also be used with these statistics—Agility, Melee, d10+5.

*Primary Weapon - Tier 3*
