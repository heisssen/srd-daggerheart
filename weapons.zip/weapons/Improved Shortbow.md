﻿# IMPROVED SHORTBOW

**Trait:** Agility; **Range:** Far; **Damage:** d6+6 phy; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 2*
