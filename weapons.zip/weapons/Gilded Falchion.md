﻿# GILDED FALCHION

**Trait:** Strength; **Range:** Melee; **Damage:** d10+4 phy; **Burden:** One-Handed

**Feature:** ***Powerful:*** On a successful attack, roll an additional damage die and discard the lowest result.

*Primary Weapon - Tier 2*
