﻿# LEGENDARY DUALSTAFF

**Trait:** Instinct; **Range:** Far; **Damage:** d8+12 mag; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 4*
