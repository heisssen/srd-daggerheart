﻿# IMPACT GAUNTLET

**Trait:** Strength; **Range:** Melee; **Damage:** d10+11 phy; **Burden:** One-Handed

**Feature:** ***Concussive:*** On a successful attack, you can spend a Hope to knock the target back to Far range.

*Primary Weapon - Tier 4*
