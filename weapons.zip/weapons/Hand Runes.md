﻿# HAND RUNES

**Trait:** Instinct; **Range:** Very Close; **Damage:** d10 mag; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 1*
