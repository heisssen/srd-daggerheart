﻿# DOUBLE FLAIL

**Trait:** Agility; **Range:** Very Close; **Damage:** d10+8 phy; **Burden:** Two-Handed

**Feature:** ***Powerful:*** On a successful attack, roll an additional damage die and discard the lowest result.

*Primary Weapon - Tier 3*
