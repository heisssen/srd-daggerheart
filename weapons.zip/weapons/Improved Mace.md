﻿# IMPROVED MACE

**Trait:** Strength; **Range:** Melee; **Damage:** d8+4 phy; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 2*
