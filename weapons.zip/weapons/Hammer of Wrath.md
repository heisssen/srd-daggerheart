﻿# HAMMER OF WRATH

**Trait:** Strength; **Range:** Melee; **Damage:** d10+7 phy; **Burden:** Two-Handed

**Feature:** ***Devastating:*** Before you make an attack roll, you can mark a Stress to use a d20 as your damage die.

*Primary Weapon - Tier 3*
