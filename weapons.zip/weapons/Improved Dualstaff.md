﻿# IMPROVED DUALSTAFF

**Trait:** Instinct; **Range:** Far; **Damage:** d6+6 mag; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 2*
