﻿# IMPROVED SMALL DAGGER

**Trait:** Finesse; **Range:** Melee; **Damage:** d8+2 phy; **Burden:** One-Handed

**Feature:** ***Paired:*** +3 to primary weapon damage to targets within Melee range

*Secondary Weapon - Tier 2*
