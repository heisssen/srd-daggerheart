﻿# CURVED DAGGER

**Trait:** Finesse; **Range:** Melee; **Damage:** d8+9 phy; **Burden:** One-Handed

**Feature:** ***Serrated:*** When you roll a 1 on a damage die, it deals 8 damage instead.

*Primary Weapon - Tier 4*
