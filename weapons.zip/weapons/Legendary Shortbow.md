﻿# LEGENDARY SHORTBOW

**Trait:** Agility; **Range:** Far; **Damage:** d6+12 phy; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 4*
