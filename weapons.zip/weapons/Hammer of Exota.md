﻿# HAMMER OF EXOTA

**Trait:** Instinct; **Range:** Melee; **Damage:** d8+6 mag; **Burden:** Two-Handed

**Feature:** ***Eruptive:*** On a successful attack against a target within Melee range, all other adversaries within Very Close range must succeed on a reaction roll (14) or take half damage.

*Primary Weapon - Tier 2*
