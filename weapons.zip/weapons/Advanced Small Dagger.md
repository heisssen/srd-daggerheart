﻿# ADVANCED SMALL DAGGER

**Trait:** Finesse; **Range:** Melee; **Damage:** d8+4 phy; **Burden:** One-Handed

**Feature:** ***Paired:*** +4 to primary weapon damage to targets within Melee range

*Secondary Weapon - Tier 3*
