﻿# POWERED GAUNTLET

**Trait:** Knowledge; **Range:** Close; **Damage:** d6+4 phy; **Burden:** One-Handed

**Feature:** ***Charged:*** Mark a Stress to gain a +1 bonus to your Proficiency on a primary weapon attack.

*Secondary Weapon - Tier 3*
