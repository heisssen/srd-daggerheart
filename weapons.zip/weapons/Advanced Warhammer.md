﻿# ADVANCED WARHAMMER

**Trait:** Strength; **Range:** Melee; **Damage:** d12+9 phy; **Burden:** Two-Handed

**Feature:** ***Heavy:*** -1 to Evasion

*Primary Weapon - Tier 3*
