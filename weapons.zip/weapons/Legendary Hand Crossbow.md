﻿# LEGENDARY HAND CROSSBOW

**Trait:** Finesse; **Range:** Far; **Damage:** d6+7 phy; **Burden:** One-Handed

**Feature:** —

*Secondary Weapon - Tier 4*
