﻿# ADVANCED SHORTBOW

**Trait:** Agility; **Range:** Far; **Damage:** d6+9 phy; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 3*
