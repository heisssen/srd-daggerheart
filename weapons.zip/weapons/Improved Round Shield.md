﻿# IMPROVED ROUND SHIELD

**Trait:** Strength; **Range:** Melee; **Damage:** d4+2 phy; **Burden:** One-Handed

**Feature:** ***Protective:*** +2 to Armor Score

*Secondary Weapon - Tier 2*
