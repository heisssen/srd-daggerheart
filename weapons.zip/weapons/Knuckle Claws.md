﻿# KNUCKLE CLAWS

**Trait:** Strength; **Range:** Melee; **Damage:** d6+8 phy; **Burden:** One-Handed

**Feature:** ***Doubled Up:*** When you make an attack with your primary weapon, you can deal damage to another target within Melee range.

*Secondary Weapon - Tier 4*
