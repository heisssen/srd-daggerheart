﻿# SHORTSWORD

**Trait:** Agility; **Range:** Melee; **Damage:** d8 phy; **Burden:** One-Handed

**Feature:** ***Paired:*** +2 to primary weapon damage to targets within Melee range

*Secondary Weapon - Tier 1*
