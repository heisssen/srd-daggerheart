﻿# IMPROVED SHORTSTAFF

**Trait:** Instinct; **Range:** Close; **Damage:** d8+4 mag; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 2*
