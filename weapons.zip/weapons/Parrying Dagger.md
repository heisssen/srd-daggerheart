﻿# PARRYING DAGGER

**Trait:** Finesse; **Range:** Melee; **Damage:** d6+2 phy; **Burden:** One-Handed

**Feature:** ***Parry:*** When you are attacked, roll this weapon’s damage dice. If any of the attacker’s damage dice rolled the same value as your dice, the matching results are discarded from the attacker’s damage dice before the damage you take is totaled.

*Secondary Weapon - Tier 2*
