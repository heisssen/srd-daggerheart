﻿# ADVANCED RAPIER

**Trait:** Presence; **Range:** Melee; **Damage:** d8+6 phy; **Burden:** One-Handed

**Feature:** ***Quick:*** When you make an attack, you can mark a Stress to target another creature within range.

*Primary Weapon - Tier 3*
