﻿# SPIKED SHIELD

**Trait:** Strength; **Range:** Melee; **Damage:** d6+2 phy; **Burden:** One-Handed

**Feature:** ***Double Duty:*** +1 to Armor Score; +1 to primary weapon damage within Melee range

*Secondary Weapon - Tier 2*
