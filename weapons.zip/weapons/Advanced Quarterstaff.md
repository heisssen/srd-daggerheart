﻿# ADVANCED QUARTERSTAFF

**Trait:** Instinct; **Range:** Melee; **Damage:** d10+9 phy; **Burden:** Two-Handed

**Feature:** —

*Primary Weapon - Tier 3*
