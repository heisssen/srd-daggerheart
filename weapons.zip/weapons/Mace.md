﻿# MACE

**Trait:** Strength; **Range:** Melee; **Damage:** d8+1 phy; **Burden:** One-Handed

**Feature:** —

*Primary Weapon - Tier 1*
